
byte shell(char*);
byte builtin_echo(char*);
byte builtin_hello(char*);

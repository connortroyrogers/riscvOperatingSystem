#ifndef H_SLEEP
#define H_SLEEP

#include <barelib.h>

/*  sleep related prototypes */
int32 sleep(uint32, uint32);
int32 unsleep(uint32);

#endif
